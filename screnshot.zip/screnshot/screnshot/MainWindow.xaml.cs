﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;
using System.IO;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Linq;

namespace screnshot
{
    public partial class MainWindow : Window
    {
        private string projectFolder;
        private int currentIndex = -1;
        private string[] screenshotFiles;

        public MainWindow()
        {
            InitializeComponent();

            projectFolder = AppDomain.CurrentDomain.BaseDirectory;
            screenshotFiles = Directory.GetFiles(projectFolder, "screenshot*.png").OrderBy(f => f).ToArray();
        }

        private void TakeScreenshotBTN(object sender, RoutedEventArgs e)
        {
            TakeScreenshot();
        }

        private void PreviousBTN(object sender, RoutedEventArgs e)
        {
            if (currentIndex > 0)
            {
                currentIndex--;
                ShowScreenshot();
            }
        }

        private void NextBTN(object sender, RoutedEventArgs e)
        {
            if (currentIndex < screenshotFiles.Length - 1)
            {
                currentIndex++;
                ShowScreenshot();
            }
        }

        private void TakeScreenshot()
        {
            // Get the size of the primary screen
            System.Drawing.Rectangle screenBounds = new System.Drawing.Rectangle((int)SystemParameters.VirtualScreenLeft, (int)SystemParameters.VirtualScreenTop, (int)SystemParameters.VirtualScreenWidth, (int)SystemParameters.VirtualScreenHeight);

            // Create a bitmap with the screen size
            Bitmap bmp = new Bitmap(screenBounds.Width, screenBounds.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);

            // Copy the screen to the bitmap
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.CopyFromScreen(screenBounds.Left, screenBounds.Top, 0, 0, bmp.Size);
            }

            // Save the encoded image to the project's own folder
            string filePath = GetUniqueFilePath();
            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                PngBitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(BitmapSourceFromBitmap(bmp)));
                encoder.Save(stream);
            }

            currentIndex = screenshotFiles.Length;
            screenshotFiles = Directory.GetFiles(projectFolder, "screenshot*.png").OrderBy(f => f).ToArray();
            ShowScreenshot();
        }

        private string GetUniqueFilePath()
        {
            string fileName = $"screenshot{DateTime.Now:yyyyMMddHHmmss}.png";
            return Path.Combine(projectFolder, fileName);
        }

        private void ShowScreenshot()
        {
            if (currentIndex >= 0 && currentIndex < screenshotFiles.Length)
            {
                using (FileStream stream = new FileStream(screenshotFiles[currentIndex], FileMode.Open, FileAccess.Read))
                {
                    BitmapImage image = new BitmapImage();
                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.StreamSource = stream;
                    image.EndInit();
                    myImageElement.Source = image;
                }
            }
        }


        private BitmapSource BitmapSourceFromBitmap(Bitmap bitmap)
        {
            IntPtr hBitmap = bitmap.GetHbitmap();
            BitmapSource bitmapSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(hBitmap, IntPtr.Zero, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            bitmapSource.Freeze();
            DeleteObject(hBitmap);
            return bitmapSource;
        }

        [DllImport("gdi32.dll")]
        private static extern IntPtr GetDC(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ReleaseDC(IntPtr hWnd, IntPtr hDC);

        [DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);


        private const int SRCCOPY = 0xCC0020;
    }
}
